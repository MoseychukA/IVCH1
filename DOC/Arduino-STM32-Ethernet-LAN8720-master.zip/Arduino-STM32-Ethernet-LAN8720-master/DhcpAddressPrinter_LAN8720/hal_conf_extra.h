//#define HAL_ETH_MODULE_ENABLED // For core version 2.2 or earlier
#define HAL_ETH_LEGACY_MODULE_ENABLED // For core version 2.3 or later
#define LAN8742A_PHY_ADDRESS 0x01U
