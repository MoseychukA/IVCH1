UDP Broadcast Client using LAN8720 PHY   

You can use receive.py as UDP receiver.   
![UDP_Broadcast](https://github.com/user-attachments/assets/0c298f4a-a8d8-4c1b-ba64-af00ac7f1e32)
