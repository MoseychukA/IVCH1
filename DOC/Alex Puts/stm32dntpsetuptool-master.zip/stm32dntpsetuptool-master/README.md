# stm32dntpsetuptool
GUI program for setting up [stm32duino based ntp server](https://github.com/AlexPutz/stm32dntp)

![stm32dntpsetuptool screenshot](https://raw.github.com/AlexPutz/stm32dntpsetuptool/master/screenshots/ntp_broadcast_setup_tool.png)
![stm32dntpsetuptool) screenshot2](https://raw.github.com/AlexPutz/stm32dntpsetuptool/master/screenshots/ntp_broadcast_setup_tool_ntpservsettings.png)
