Please see http://www.oracle.com/technetwork/goto/javase/thirdpartyreadme/6
