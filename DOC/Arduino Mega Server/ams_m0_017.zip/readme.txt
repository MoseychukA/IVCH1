Arduino Mega Server for M0 (Zero)
version 0.17
�Hi-Lab.ru, 2018
  
License: Free for personal use, "as is" and without any warranties
Home:    https://hi-lab.ru/arduino-mega-server (russian)
         https://hi-lab.ru/english/arduino-mega-server (english)
Email:   info@hi-lab.ru

For commercial use and projects version AMS Pro:
https://hi-lab.ru/arduino-mega-server/ams-pro

Hardware
--------
Arduino M0 (Zero)
Ethernet Shield
microSD card

Software
--------

IDE: Arduino 1.8.5
  Processing 1.5.1
  Arduino SAMD Boards (32-bits ARM Cortex-M0+) 1.6.18

Arduino IDE settings
--------------------
Path to sketches folder:
...\ams_m0\Arduino

Sketches:
------------------  
Arduino Mega Server:      arduino_mega_server.ino
Arduino Serial Commander: arduino_serial_commander.pde
  
Quick start:
------------
1. Put files from folder "sd" to microSD card (to root)
2. Load sketch "arduino_mega_server" to Arduino M0
3. Open on your browser address 192.168.1.38
4. Enjoy and donate on page http://hi-lab.ru/arduino-mega-server/details/donate
