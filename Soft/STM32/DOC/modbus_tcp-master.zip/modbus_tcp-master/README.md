# ModbusTCP on STM32+W5500
## Test board: STM32F429I-DISCO

## FreeModbus
### FreeModbus API: https://www.embedded-experts.at/en/freemodbus/api-documentation/
### FreeModbus lib.: https://www.embedded-experts.at/en/freemodbus-downloads/

## W5500
### ioLibrary: https://github.com/Wiznet/ioLibrary_Driver/
