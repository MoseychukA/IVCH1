# stm32dntp

PIN Connections (Using STM32F103):

ENC28J60             | STM32F103        |
------------------   |------------------|
Q3                   | 3.3V             |
SCK                  |PA5               |
SO                   |PA6               |
SI                   |PA7               |
CS                   |PA8               |
RST                  |3.3V              |


GPS                  | STM32F103        |
------------------   |------------------|
RX                   |PA9               |
TX                   |PA10              |



