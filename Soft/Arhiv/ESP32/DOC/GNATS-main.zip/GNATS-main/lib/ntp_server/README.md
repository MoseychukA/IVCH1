# ntp_server

[ntp_server](lib/ntp_server/ntp_server.h) is a modified version of the NTP server (`ntp_server.h` and `ntp_server.cpp`) in the ElektorLabs GitHub repository [180662 mini NTP with ESP32](https://github.com/ElektorLabs/180662-mini-NTP-ESP32). 

There is a project description in the ElektorMag [mini-NTP server with GPS](https://www.elektormagazine.com/labs/mini-ntp-server-with-gps) (April 11, 2019)

## Licence
  GPLv3 or later at user choice.
